<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        
        h1{

    font-style: italic;
    color: orange;
}

h2{
color: orange;
font-style: italic;}
button{
    background-color:black;
    font-style: italic;}

a{
color:orange;
font-style: italic;
font-family: 'Courier New', Courier, monospace;
text-decoration: none;
}
body{
background-color:#115686;
font-style: italic;
}
form{
    font-style: italic;
border-radius: 40px;

}
.colt{
color: white;
font: 40px;
}

img{
    width: 100px;
    height: 400px;
}


        .Reg{
            color: white;
            border: 3px solid #444;
            border-radius: 40px;
            width: 450px;
            height: 450px;
            margin-left: auto;
            margin-right: auto;
            margin-top: 10%;
            background-image: url(img/bg6.jpeg);
            display: flex;
            flex-direction: column;
            align-items: center;
            font-style: italic;

        }

        
        .Reg:before{
            background: url('img/bg-1.jpg') center no-repeat;
            background-size: cover;
            content: '';
            height: 100vh;
            position: absolute;
                top: 50%;
                left: 50%;
                z-index: -1;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            width: 100vw;
            font-style: italic;
        }
       
        .Reg button {
            text-align: center;
            background-color: black;
            margin-left: 0;
        }


.Reg input,label{
    border-radius: 20px;
    font-family: 'Courier New', Courier, monospace;
    color: orange;

}



#r_reg{
    background-color:black;
}


</style>
</head>
<body>
    <div class="Reg">
        <form action="contact.php" method="post"><a href="Main.php"></a>
            <button><a href="Main.html">Go back to Main page</a></button>
            <h2>Please created your account!</h2>
            <img src="img/logl2.png" alt="Tanirbergen Merei" style="height:90px"><br>
            <label for="username">Username:</label><br>
            <input type="text" id="r_log" name="r_log"><br>
            <label for="phone">Phone number:</label><br>
            <input type="number" id="p_log" name="p_log"><br>
            <label for="email">Email:</label><br>
            <input type="text" id="r_email" name="r_email"><br>
            <label for="pwd">Password:</label><br>
            <input type="text" id="pwd" name="pwd"><br>
            <label for="pwd">Repeat Password:</label><br>
            <input type="text" id="rpwd" name="rpwd"><br><br>
            <input type="submit"  id="r_reg" name="r_reg" value="Register">
          </form>
    </div>
</body>
</html>