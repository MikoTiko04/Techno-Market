<!DOCTYPE html>
<html>
<head>
    <title>TM</title>
    <link rel="website icon"  type="png" href="img/new_logo_1.png">
    <style>
        @import url(https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css);




.header-line {
  padding-top: 50px;
  display: flex;
  align-items: center;
  justify-content: space bar;
}

.nav-a {
  color: orange;
  text-decoration: none;
  font-weight: 700;
  font-size: 14px;

  margin-right: 25px;

  transition: color 0.3s linear;
}

.nav-a:hover {
  color: #d81d1d;
}

body {
  margin: 0;
  font-family: 'Open Sans', sans-serif;
  background-image: url(img/bg6.jpeg);
  height: 100vh;
  background-repeat: no-repeat;
  background-size: cover;
  text-align: center;
  height: 100%;
}

.wrapper{
  min-height: 100%;
  display: flex;
  flex-direction: column;
}

.container {
  margin: 0px 166px;
}




.log1:hover {
  color: #d81d1d;
}
.log2:hover {
  color: #d81d1d;
}
.header-logo {
  position: absolute;
  left: 1%;
  border-radius: 6px;
  text-decoration: none;
animation: rotate 5s linear infinite; /* Анимация: вращение в течение 5 секунд бесконечно */
}




.log1 {
    position: absolute;
    right: 10%;
    border-radius: 6px;
    text-decoration: none;
    color: orange;
}
.log2 {
    position: absolute;
    right: 5%;
    border-radius: 6px;
    text-decoration: none;
    color: orange;
}
.user-info{
  position: absolute;
  right: 15%;
  border-radius: 6px;
  text-decoration: none;
  color: orange;
}
  


    footer{
      margin-top: 30px;
      position: relative;
      justify-content: center;
      background-color: rgb(217, 217, 217);
      
    }
    .fa {
        padding: 20px;
        font-size: 30px;
        width: 70px;
        text-align: center;
        text-decoration: none;
        margin: 5px 2px;
        border-radius: 50%;
      }
      
      .fa:hover {
          opacity: 0.7;
      }
      
      .fa-facebook {
        background: #3B5998;
        color: white;
      }
      
      .fa-twitter {
        background: #55ACEE;
        color: white;
      }
      
      .fa-google {
        background: #dd4b39;
        color: white;
      }
      
      .fa-linkedin {
        background: #007bb5;
        color: white;
      }
      
      .fa-youtube {
        background: #bb0000;
        color: white;
      }
      
      .fa-instagram {
        background: #125688;
        color: white;
      }
      .his{
        text-align: center;
        font-family: 'Courier New', Courier, monospace;
        font-size: larger;
        
        
      }
      .box{
        width: 100%;
        margin-left: 0%;
        text-align: center;
        font-family: 'Courier New', Courier, monospace;
        font-size: larger;
        margin-top: 900px;
      }
    
     .phone img{
      height: 25px;
      width: 25px;
      position: absolute;
      left: 44.5%;
      border-radius: 6px;
      text-decoration: none;
      margin-top: -2px;
     }
    
   
  .content{
    border: 2px; /* Рамка вокруг фотографии */
    padding: 10px; /* Расстояние от картинки до рамки */
    margin-right: 5px; /* Отступ справа */
    margin-bottom: 5px; /* Отступ снизу */
    transition: 1s; /* Время эффекта */
    flex: 0 0 calc(33.33% - 20px); /* Распределение равного пространства на ширину, с учетом отступов */
    margin: 5px; /* Отступы между элементами .content */
    text-align: center; /* Выравниваем содержимое по центру горизонтально */
    box-sizing: border-box; /* Учитываем отступы и границы в расчетах ширины */
  }
  .row{
    margin: 10px -16px;
    position: absolute;
    left: 2%;
    display: flex; /* Превращаем контейнер .row в гибкий (flex) контейнер */
    flex-wrap: wrap; /* Разрешаем перенос элементов на новую строку, если не помещаются в одну строку */
    justify-content: center; /* Выравниваем элементы по горизонтали по центру */
  }

    
  
  .content .buy{
    color:#0072c6;
    border-radius: 3px;
    border-color: coral;
    margin-right: auto;
    font-size: larger;
    text-decoration: none;
transition: color 0.3s linear;
font-family: 'Courier New', Courier, monospace;
}

.buy:hover {
  color: red;
}


.content h4{
color: black;
font-family: 'Courier New', Courier, monospace;
}


/* Clear floats after rows */ 
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* The "show" class is added to the filtered elements */
.show {
display: block;
}

.mash {
display: inline-block; /* Строчно-блочный элемент */
overflow: hidden; /* Скрываем всё за контуром */
text-align: center; /* Выравниваем содержимое по центру горизонтально */
}
.mash img {
transition: 1s; /* Время эффекта */
display: block; /* Убираем небольшой отступ снизу */
overflow: hidden; width: 450px;
float: left; margin-right: 10px; margin-bottom: 10px;
width: 200px; height: 200px; object-fit: cover; 
}
.mash img:hover {
transform: scale(1.2); /* Увеличиваем масштаб */
}
.ccn{
  background-color: rgb(217, 217, 217);
  position: absolute;
    left: auto;
    right: auto;
    margin-top: 1470px;
    height: 1500px;
  
}
.buy img {
  max-width: 30px; /* Желаемая максимальная ширина */
  max-height: 15px; /* Желаемая максимальная высота */
}
.em{
  color: orange;
  text-decoration: none;
  transition: color 0.3s linear;
}
.em:hover {
  color: red;
}


.topic {
     display: flex;
    justify-content: center;
    margin-bottom: 20px;
    font-family: 'Tinos', serif;
    font-size: 26px;
    font-weight: 400;
    

}

.topic span {
    color: #D67E35;
    margin-left: 15px;
}

.topic_text {
    text-align: center;
    font-family: 'Tinos', serif;
    font-size: 50px;
    font-weight: 400;
    color: #03a9f4;
    animation: animate 4s ease-in-out infinite;
}
@keyframes animate{
  0%,100%{
  clip-path: polygon(0% 30%, 6% 40%, 12% 68%, 19% 69%, 28% 69%, 38% 68%, 46% 65%, 53% 59%, 59% 52%, 67% 46%, 76% 41%, 84% 40%, 94% 39%, 100% 39%, 100% 100%, 0 100%);}
  
  90%{
 clip-path: polygon(0% 59%, 7% 53%, 14% 47%, 22% 40%, 32% 41%, 39% 44%, 46% 52%, 52% 59%, 56% 65%, 64% 72%, 72% 74%, 82% 75%, 91% 69%, 100% 59%, 100% 100%, 0 100%);
  }
}

.his{
    font-family:'Courier New', Courier, monospace;
    text-align: center;
    font-size: 54px;
font-weight: 400;
}

.his span {
    color: #D67E35;
}

.his_text {
  color: #03a9f4;
    font-size: 17px;
    text-align: center;
}


.his_num {
    display: flex;
    width: 444px;
    justify-content: center;
    margin-top: 40px;
    margin-left:auto;
    margin-right: auto;
}

.num_i {
    margin-right: 60px;
    text-align: center;
    font-size: 40px;
    color: orange;
}

.num_i span {
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0);
    background: url(img/aa1.jpg) repeat-x;
    background-clip: text; 
    -webkit-background-clip: text;
    background-size: contain;
    animation: fire 15s linear infinite;
}

    



@keyframes fire {
    0% {
        background-position: left 0 top 25px;
    }

    50% {
        background-position: left 130px top -35px;
    }

    100% {
        background-position: left 260px top 0;
    }
}






.slider-container {
  position: relative;
  width: 400px;
  height: 500px;
  margin: 0 auto;
  overflow: hidden;
  margin-top: 100px;
}

.slider {
  display: flex;
  transition: transform 0.5s ease-in-out;
}

.slider img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.prev-button,
.next-button {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 50px;
  height: 50px;
  background-color: transparent;
  border: none;
  font-size: 24px;
  color: white;
}

.prev-button {
  left: 10px;
}

.next-button {
  right: 10px;
}
:root {
  --card-height: 300px;
  --card-width: calc(var(--card-height) / 1.5);
}
* {
  box-sizing: border-box;
}

@import url(https://fonts.googleapis.com/css?family=Montserrat);
.containerr {
  display: flex;
  height: 100%;
  align-items: center;
}

svg {
    display: block;
    font: 8em 'Montserrat';
    width: 960px;
    height: 300px;
    margin: 0 auto;
}

.text-copy {
    fill: none;
    stroke: white;
    stroke-dasharray: 6% 29%;
    stroke-width: 5px;
    stroke-dashoffset: 0%;
    animation: stroke-offset 5.5s infinite linear;
}

.text-copy:nth-child(1){
  stroke: rgb(217, 217, 217);
  animation-delay: -1;
}

.text-copy:nth-child(2){
  stroke: white;
  animation-delay: -2s;
}

.text-copy:nth-child(3){
  stroke: red;
  animation-delay: -3s;
}

.text-copy:nth-child(4){
  stroke: blue;
  animation-delay: -4s;
}

.text-copy:nth-child(5){
  stroke: orange;
  animation-delay: -5s;
}

@keyframes stroke-offset{
  100% {stroke-dashoffset: -35%;}
}

.cards-holder {
  display: flex;
  justify-content: space-between;
  margin-top: 150px;
}


.card {
  width: 349px;
  box-shadow: 10px 10px 40px 20px #0000001A;
  margin-right: 31px;
  background-color: rgb(217, 217, 217);
  margin-top: -80px;
  padding: 10px 10px;
}

.card-image {
  display: flex;
  justify-content: center;
  padding-top: 31px;
}

.card-title {
   display: flex;
  justify-content: center;
  margin-bottom: 20px;
  font-family: 'Tinos', serif;
  font-size: 26px;
  font-weight: 400;

}

.card-title span {
  color: #D67E35;
  margin-left: 10px;
}

.card-desc {
  text-align: center;
  font-family: 'Tinos', serif;
  font-size: 26px;
  font-weight: 400;
  color: #03a9f4;
}
.card-img{
  width: 250px;
  height: 200px;
}

.about{
  text-align: center;
  font-family: 'Courier New', Courier, monospace;
  font-size: 26px;
  margin-top: 400px;
}
.abb{
  color: orange;
}
.pabb{
color: #0072c6;
}
number{
  font-family:Georgia, 'Times New Roman', Times, serif
}
.container2{
	position: relative;
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 30px 100px;
  margin-top: 1630px;
  
}

.container2:after{
	content: '';
	position: absolute;
	width: 100%;
	height: 100%;
	left: 0;
	top: 0;
    background: url(img/bg-1.jpg)no-repeat center;
    background:  linear-gradient (to top, #b01313, #008c05) fixed;
    animation: city 30s linear infinite;
    -webkit-animation: city 30s linear infinite;
	background-size: cover;
	filter: blur(10px);
	z-index: -1;
}
@keyframes city {
    from { background-position: -1000px 100%, 120% 30%, 120% 15%, 0 0;}
    to { background-position: 0 100%, -200% 10%, -50% 15%, 0 0; }
   }
.contact-box{
    max-width: 900px;
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	justify-content: center;
	align-items: center;
	text-align: center;
	background-color:white;
	box-shadow: 0px 0px 19px 5px rgba(0,0,0,0.19);
}

.left{
	background: url("img/bg-1.jpg") no-repeat center;
	background-size: cover;
	height: 100%;
}

.right{
	padding: 25px 40px;
    margin-right: 20px;
}

h2{
    position: relative;
	padding: 0 0 10px;
	margin-bottom: 10px;
  color: orange;
  font-family: 'Courier New', Courier, monospace;
    font-style: italic;
}

h2:after{
    content: '';
    position: absolute;
    left: 50%;
    bottom: 0;
    color: orange;
    transform: translateX(-50%);
    height: 4px;
    width: 50px;
    border-radius: 2px;
    background-color: #00000000;
}

.field{
	width: 100%;
	border: 2px solid rgba(0, 0, 0, 0);
	outline: none;
	background-color: rgba(230, 230, 230, 0.6);
	padding: 0.5rem 1rem;
	font-size: 1.1rem;
	margin-bottom: 22px;
	transition: .3s;
}

.field:hover{
	background-color:floralwhite
}
.right input,textarea,button{
    color: orange;
    background-color: rgba(230, 230, 230, 0.6);
  }

textarea{
	min-height: 150px;
}

.btn{
	width: 100%;
	padding: 0.5rem 1rem;
	background-color: #00000000;
	color:orange;
	font-size: 1.1rem;
	border: none;
	outline: none;
	cursor: pointer;
	transition: .3s;
  font-family: 'Courier New', Courier, monospace;
  font-style: italic;
  border: 2px solid rgba(30,85,250,0.47);
}

.btn:hover{
    background-color:#0072c6;
}
.btn a{
    text-decoration: none;
    color: orange;
    font-family: 'Courier New', Courier, monospace;
    font-style: italic;
  }

.field:focus{
    border: 2px solid rgba(30,85,250,0.47);
    background-color: #00000000;
}

@media screen and (max-width: 880px){
	.contact-box{
		grid-template-columns: 1fr;
	}
	.left{
		height: 200px;
	}
}
::-webkit-input-placeholder { /* WebKit browsers */
    color:#0072c6;
    font-family: 'Courier New', Courier, monospace;
    font-style: italic;
  }
 
  .crud-button {
    font-size: 14px;
    color: orange;
    font-weight: bold;
    margin-top: 20px;
    margin-left: 900px;
    text-decoration: none;
    background: none;
    border: none;
    cursor: pointer;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
    margin-top: 5px;
    padding: 10px;
}

.log2:hover .dropdown-content {
    display: block;
}

 

    </style>
</head>
<body>
<div class="wrapper">
  <div class="header" position: fixed; z-index: 3; top: 0;>
    <div class="container">
      <div class="header-line">
              <div class='header-logo'>
              <img src="img/new_logo_1.png" alt="">
                </div>
            <div class="nav">
          <a class="nav-a" href="Main.html">Home</a>
          <a class="nav-a" href="2page.html">Phones</a>
          <a class="nav-a" href="3page.html">Laptops</a>
          <a class="nav-a" href="4page.html">About us</a>
          <a class="nav-a" href="5page.html">Support</a>
  <?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Check if the user is an administrator
    if (isset($_SESSION['username']) && $_SESSION['username'] == 'admin') {
        echo "<div class='log2'>
            <a class='crud-button' href='#'>Cabinet</a>
            <div class='dropdown-content'>
                <p>Hello World!</p>
            </div>
        </div>";
    }

    echo "<div class='log1' style='font-size: 16px; color: orange; font-weight: bold; margin-top: -30px; margin-right: -50px;'> $username</div>";
     echo "<form action='logout.php' method='post'>
    <div class='log3'style='font-size: 14px; color: orange; font-weight: bold; margin-top: -10px; margin-left: 1120px; text-decoration: none; background: none; border: none; hover: color: #d81d1d;'><button type='submit' class='logout-button' style='text-decoration: none; background: none; border:none;font-weight: bold;'>Logout</button></div> </form>";
} else {
    echo "<a class='log1' href='regf.php'>Register</a>";
    echo "<a class='log2' href='n_log.html'>Login</a>";
}
?>

    
</div>

          </div>
        </div>
  </div>
</div>








<div class="containerr">
  <svg viewBox="0 0 960 300">
    <symbol id="s-text">
      <text text-anchor="middle" x="50%" y="80%">Our Products</text>
    </symbol>

    <g class = "g-ants">
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
    </g>
  </svg>
</div>

<div class="slider-container">
	    <div class="slider">
	      <img src="img/png/i-14_black-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/S-54-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/H-50-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/O-78-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/H-60-removebg-preview.png" width="100" height="100" alt="Laptops">
        <img src="img/png/i-14_fil-removebg-preview.png" width="100" height="100" alt="Laptops">
        <img src="img/png/S23-removebg-preview.png" width="100" height="100" alt="Laptops">
        <img src="img/png/S21-removebg-preview.png" width="100" height="100" alt="Laptops">
	    </div>
	    <button class="prev-button" type="button" aria-label="Посмотреть предыдущий слайд">&lt;</button>
	    <button class="next-button" type="button" aria-label="Посмотреть следующий слайд">&gt;</button>
	  </div>
    <script src="script2.js"></script>



    <div class='cards'>

      <div class='container'>
  
         <div class='cards-holder'>
  
              <div class='card'>
  
                  <div class='card-image'>
                      <img class='card-img' src='img/card3_1.png'>
                  </div>
  
                  <div class='card-title'>
                    Best    <span>Technologies</span>
                  </div>
  
                  <div class='card-desc'>
                    Our store offers you world brands recognized by users
                  </div>
  
              </div>
  
              <div class='card'>
  
                  <div class='card-image'>
                      <img class='card-img' src='img/card3_1.png'>
                  </div>
  
                  <div class='card-title'>
                      Good  <span>Products</span>
                  </div>
  
                  <div class='card-desc'>
                    We have our suppliers in America, Europe, Asia
  
                  </div>
  
              </div>
  
              <div class='card'>
  
                  <div class='card-image'>
                      <img class='card-img' src='img/card3_1.png'>
                  </div>
  
                  <div class='card-title'>
                    Legitimate  <span>Prices</span>
                  </div>
  
                  <div class='card-desc'>
                    We have fair prices and low margins on our products
                  </div>
  
              </div>
  
          </div>
      </div>
    </div>














<div class="ccn">
  <div class="topic">
  Market <span>Products </span></div>
  <div class="topic_text">
    Our store provides only the best products
  </div>
<div class="row">
    <br><div class="content">
      <a href="log.html" class="mash" ><img src="img/png/i-removebg-preview.png" alt="Apple" style="width:100%"></a>
      <h4>Iphone 11 128GB  Black</h4><br>
      <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
    </div>
  
    <div class="content">
      <a href="log.html" class="mash" ><img src="img/png/i-14_fil-removebg-preview.png" alt="Apple" style="width:100%"></a>
      <h4>Iphone 14 Pro Max 256GB Violet</h4>
      <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
    </div><br>
  

    <div class="content">
      <a href="log.html" class="mash" ><img src="img/i-15pro.avif" alt="Apple" style="width:100%"></a>
      <h4>Iphone 15 Pro Max 256GB Gold</h4>
       <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
    </div><br>
      <div class="content">
        <a href="log.html" class="mash" ><img src="img/png/A-15_1.png" alt="Asus" style="width:100%"></a>
        <h4>ASUS TUF Gaming F15 FX506HE Black</h4><br>
        <a  class="buy" href="2page.html"> <img src="img/card.png" alt="">Buy</a> 
      </div>
      <div class="content">
        <a href="log.html" class="mash" ><img src="img/png/A-16-removebg-preview.png" alt="Asus" style="width:100%"></a>
        <h4>ASUS ROG Zephyrus M16 Black</h4><br>
        <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
      </div>
   
      <div class="content">
        <a href="log.html" class="mash" ><img src="img/png/A-90-removebg-preview.png" alt="Asus" style="width:100%"></a>
        <h4>ASUS 15 F515EA-BQ2187W Gray</h4><br>
        <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a>
        
      
    </div>
</div>
      <div class="box">
         <div class="his">
          Techno <span>Market</span>
         </div>
         <div class='his_text'>
              We are pleased to offer you a wide range of products from world leaders in innovative technologies. Here you can buy the latest models of iPhone, Oppo, Asus, Acer and other devices that impress with their quality and functionality.We are proud to provide only original products from leading companies that have passed rigorous testing and meet the highest quality standards. Our team is ready to help you choose and purchase the perfect device, as well as provide professional advice on all issues.

Do not postpone your dreams for later - make your life more comfortable and efficient with the products of world brands. Buy with confidence in our online store and enjoy advanced technologies today!
         </div>
         <div class='his_num'>
          <div class='num_i'>
              79 <span>Phones</span>
          </div>

          <div class='num_i'>
              32 <span>Laptops</span>
          </div>

          <div class='num_i'>
              102 <span>Accessories</span>
          </div>
      </div>
         </div>
        </div>
      </div>
      

  
   
  

<script src="js/anime.min.js"></script>
<script>
var animation = anime({
  targets: '.header-logo',
  rotate: {
    value: 360,
    duration: 2500, // Продолжительность анимации в миллисекундах (1 секунда)
    easing: 'easeInOutSine' // Эффект сглаживания для плавности анимации
  },
  loop: true
});
</script>

<script>
  var animation = anime({
  targets: '.card',
  translateX: 180,
  delay: function(el, i) { return i * 100; },
  direction: 'alternate',
  loop: true,
  easing: 'easeInOutSine'
});

document.querySelector('.restart-demo .restart').onclick = animation.restart;
</script>

<div class="container2">
<form action="contact.php" method="post">
  <div class="contact-box">
    <div class="left"></div>
    <div class="right">
      <h2>Contact Us</h2>
      <input type="text" class="field" placeholder="Your Name" id="uname" name="uname">
      <input type="text" class="field" placeholder="Your Phone" id="upho" name="upho">
      <input type="text" class="field" placeholder="Address" id="uadd" name="uadd">
      <textarea placeholder="Message" class="field" id="umes" name="umes"></textarea>
      <button class="btn" id="btn" name="btn"><a href="https://wa.me/87089713828?text=Hello! I want a consultation." id="btn" name="btn">Send</a></button>
    </div>
  </div>
</form>
</div>
  

<footer>
  <a href="mailto:TikoMiko@example.com" class="em">Email:TikoMiko@example.com</a>
  <div class="phone">
      <img src="img/call.png" alt="">
      <p>+87089717777</p>
  </div>
   <div class="sc">
<a href="https://www.facebook.com/" class="fa fa-facebook"></a>
<a href="https://twitter.com/?lang=en" class="fa fa-twitter"></a>
<a href="https://www.google.co.uk/" class="fa fa-google"></a>
<a href="https://kz.linkedin.com/" class="fa fa-linkedin"></a>
<a href="https://www.youtube.com/channel/UC2c3f-eBCcobf3WiYj1P_Qg" class="fa fa-youtube"></a>
<a href="https://www.instagram.com/mikh_ailkutuzov/" class="fa fa-instagram"></a>
</div>
</footer>










</div>

</body>
</html>