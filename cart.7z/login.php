<?php
if (isset($_GET['logsub'])) {
    $login = $_GET['r_log'];
    $password = $_GET['pwd']; 
    // Подключение к базе данных
    $host = "localhost";
    $username = "root";
    $dbpassword = "";
    $dbname = "test2";

    $con = mysqli_connect($host, $username, $dbpassword, $dbname);
    $password = md5($password);
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM `users7` WHERE u_log = '$login' AND pass = '$password'";
    $result = mysqli_query($con, $sql);

    if ($result->num_rows > 0) {
       while($row = $result->fetch_assoc()){
        echo "Welcome " . $row['u_log'];
       }
    } else {
        echo "Invalid login or password";
    }

}
?>