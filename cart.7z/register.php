<?php

if(isset($_POST['r_reg'])){

    $login = $_POST['r_log'];
    $email = $_POST['r_email'];
    $password = $_POST['pwd'];
    $rpassword = $_POST['rpwd'];
    $p_log = $_POST['p_log'];

//database details. You have created these details in the third step. Use your own.
$host = "localhost";
$username = "root";
$password = "";
$dbname = "test2";

//create connection
$con = mysqli_connect($host, $username, $password, $dbname);
//check connection if it is working or not
if (!$con)
{
    die("Connection failed!" . mysqli_connect_error());
}

$sql = "INSERT INTO `users7` (id, u_log, email, pass, phone) VALUES ('0', '$login', '$email','$password','$p_log')";

//fire query to save entries and check it with if statement
$rs = mysqli_query($con, $sql);
if($rs)
{
    echo "Message has been sent successfully!";
}
else{
    echo "Error, Message didn't send! Something's Wrong."; 
}
//connection closed.
mysqli_close($con);
}
header('Location: /Main.php');
?>



