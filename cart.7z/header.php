<header class="header">

   <div class="flex">


              <img src="img/new_logo_1.png" alt="" class="logo">
                

      <nav class="navbar">
         <a href="admin.php">add products</a>
         <a href="tt.php">Main</a>
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

      <a href="cart.php" class="cart">cart </a>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>