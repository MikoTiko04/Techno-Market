<?php
session_start();

if(isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";

    $con = mysqli_connect($host, $username, $password, $dbname);

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT id, username, password FROM users WHERE username = '$username'";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            header('Location: dashboard.php'); // Перенаправляем на страницу после входа
        } else {
            $error_message = "Неверный пароль";
        }
    } else {
        $error_message = "Пользователь не найден";
    }

    mysqli_close($con);
}
