<?php
require_once('db.php');
session_start(); // Начало сессии

$login = $_POST['r_log'];
$pass = $_POST['pwd'];

if (empty($login) || empty($pass)) {
    echo "Please write";
} else {
    $sql = "SELECT * FROM `users7` WHERE u_log = '$login' AND pass = '$pass'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['username'] = $row['u_log']; // Сохранение логина в сессии
            header('Location: http://lab/server/Main.php');
            exit(); // Важно прервать выполнение кода после перенаправления
        }
    } else {
        echo "Invalid password or login";
    }
}
?>
