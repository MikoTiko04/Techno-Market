<?php
// database connection code
if(isset($_POST['logusername']))
{
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$con = mysqli_connect('localhost:8080', 'root', '','test1');

// get the post records

$logusername = $_POST['logusername'];
$logpwd = $_POST['logpwd'];

// database insert SQL code
$sql = "INSERT INTO `user1` (`id`, `login`, `password`) VALUES ('0', '$logusername', '$logpwd')";

// insert in database 
$rs = mysqli_query($con, $sql);
if($rs)
{
	echo "Contact Records Inserted";
}
}
else
{
	echo "Are you a genuine visitor?";
	
}
?>