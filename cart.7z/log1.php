
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title> 
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&family=Raleway:wght@400;600;700&family=Roboto:wght@300&family=Suez+One&display=swap" rel="stylesheet">
    <style>
        
        h1{
            text-align: center;
            color: orange;
        }
        
        h2{text-align: center;
        
        color: orange;
        font-style: italic;}
        p    {text-align: center;
        font-family:Raleway
;
        color: orange;}
        button{text-align: center;
            background-color:black;
        text-align: center;}
        
        a{
        color:orange;
        text-align: center;
        font-family: 'Courier New', Courier, monospace;
        text-decoration: none;
        }
        body{
        background-color:#115686;
        }
        form{
        
        border-radius: 40px;
        
        }
        .colt{
        color: white;
        font: 40px;
        }
        
        img{
            width: 100px;
            height: 400px;
        }
        
        
                .Log{
                    text-align: center;
                    color: white;
                    border: 3px solid #444;
                    border-radius: 40px;
                    width: 450px;
                    height: 450px;
                    margin-left: auto;
                    margin-right: auto;
                    margin-top: 10%;
                    background-image: url(img/bg6.jpeg);
                    display: flex;
                }
        
                
                .Log:before{
                    background: url('img/bg-1.jpg') center no-repeat;
                    background-size: cover;
                    content: '';
                    height: 100vh;
                    position: absolute;
                        top: 50%;
                        left: 50%;
                        z-index: -1;
                    -webkit-transform: translate(-50%, -50%);
                    -ms-transform: translate(-50%, -50%);
                    transform: translate(-50%, -50%);
                    width: 100vw;
                }
               
        
        
        
        .Log input,label{
            border-radius: 20px;
            font-family: 'Courier New', Courier, monospace;
            color: orange;
        
        }
        .Log button,input,label,img,h1{
            margin-left: 130px;
        
        }
        #logsub{
            background-color:black;
        }
        
        
            </style>
</head>
<body>

    <div class="Log">
    <form action="test.php" method="post">
        <button><a href="Main.html">Go back to Main page</a></button>
        <h1>LOG <span class="colt">IN </span></h1>
        <img src="img/logl2.png" alt="Tanirbergen Merei" style="height:60px"><br>
        <label for="username">Username:</label><br>
        <input type="text" id="r_log" name="r_log"><br>
        <label for="pwd">Password:</label><br>
        <input type="text" id="pwd" name="pwd"><br><br>
         <input type="submit" name="logsub" value="Login">
          </form>
        </div>
</body>
</html>