<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Форма авторизации</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 300px;
            margin: 0 auto;
            text-align: center;
        }
        h2 {
            color: #333;
        }
        form {
            border: 1px solid #ccc;
            padding: 20px;
            background-color: #f9f9f9;
        }
        input[type="text"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
        }
        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Форма входа</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="loginUsername" placeholder="Логин" required>
            <input type="password" name="loginPassword" placeholder="Пароль" required>
            <input type="submit" name="loginSubmit" value="Войти">
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["loginSubmit"])) {
            // Получаем данные из формы
            $username = $_POST["loginUsername"];
            $password = $_POST["loginPassword"];

            // Проверяем, что логин и пароль корректны (пример)
            $validUsername = "almaz";
            $validPassword = "123";

            if ($username === $validUsername && $password === $validPassword) {
             header("Location: http://localhost/indexx.php");
                
            } else {
                echo "Неправильный логин или пароль.";
            }
        }
        ?>

        <h2>Форма регистрации</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="registerUsername" placeholder="Логин" required>
            <input type="password" name="registerPassword" placeholder="Пароль" required>
            <input type="submit" name="registerSubmit" value="Зарегистрироваться">
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["registerSubmit"])) {
            // Получаем данные из формы регистрации
            $newUsername = $_POST["registerUsername"];
            $newPassword = $_POST["registerPassword"];

          
            
            echo "Вы успешно зарегистрировались!";
        }
        ?>
    </div>
</body>
</html>