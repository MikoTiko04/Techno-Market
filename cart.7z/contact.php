<?php

require_once ('db.php') ;

$login = $_POST['r_log'];
$pass = $_POST['pwd'];
$email = $_POST['r_email'];
$phone = $_POST['p_log'];

$sql="INSERT INTO `users7` (u_log, pass,email,phone ) VALUES ( '$login', '$pass', '$email', '$phone')";

$conn -> query($sql);
header('Location: http://lab/server/Main.php');
?>