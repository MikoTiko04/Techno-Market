<!DOCTYPE html>
<html>
<head>
    <title>TM</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="website icon"  type="png" href="img/new_logo_1.png">
</head>
<body>
<div class="wrapper">
  <div class="header" position: fixed; z-index: 3; top: 0;>
    <div class="container">
      <div class="header-line">
              <div class='header-logo'>
              <img src="img/new_logo_1.png" alt="">
                </div>
            <div class="nav">
          <a class="nav-a" href="Main.html">Home</a>
          <a class="nav-a" href="2page.html">Phones</a>
          <a class="nav-a" href="3page.html">Laptops</a>
          <a class="nav-a" href="4page.html">About us</a>
          <a class="nav-a" href="5page.html">Support</a>
  <?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Check if the user is an administrator
    if (isset($_SESSION['username']) && $_SESSION['username'] == 'admin') {
        
        echo "<div class='log2' style='font-size: 14px; color: orange; font-weight: bold; margin-top: 20px; margin-left: 900px; text-decoration: none; background: none; border: none; hover: color: #d81d1d;'><h3 class='crud-button'  style='text-decoration: none;background: none; border:none; font-weight: bold;'>Cabinet</h3>
        <span>Наведите на меня курсор</span>
        <div class='dropdown-content'style=''>
        <p>Hello World!</p>
        </div></div>";
    }

    echo "<div class='log1' style='font-size: 16px; color: orange; font-weight: bold; margin-top: -30px; margin-right: -50px;'> $username</div>";
     echo "<form action='logout.php' method='post'>
    <div class='log3'style='font-size: 14px; color: orange; font-weight: bold; margin-top: -10px; margin-left: 1120px; text-decoration: none; background: none; border: none; hover: color: #d81d1d;'><button type='submit' class='logout-button' style='text-decoration: none; background: none; border:none;font-weight: bold;'>Logout</button></div> </form>";
} else {
    echo "<a class='log1' href='regf.php'>Register</a>";
    echo "<a class='log2' href='n_log.html'>Login</a>";
}
?>

    
</div>

          </div>
        </div>
  </div>
</div>








<div class="containerr">
  <svg viewBox="0 0 960 300">
    <symbol id="s-text">
      <text text-anchor="middle" x="50%" y="80%">Our Products</text>
    </symbol>

    <g class = "g-ants">
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
      <use xlink:href="#s-text" class="text-copy"></use>
    </g>
  </svg>
</div>

<div class="slider-container">
	    <div class="slider">
	      <img src="img/png/i-14_black-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/S-54-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/H-50-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/O-78-removebg-preview.png" width="100" height="100" alt="Phone">
	      <img src="img/png/H-60-removebg-preview.png" width="100" height="100" alt="Laptops">
        <img src="img/png/i-14_fil-removebg-preview.png" width="100" height="100" alt="Laptops">
        <img src="img/png/S23-removebg-preview.png" width="100" height="100" alt="Laptops">
        <img src="img/png/S21-removebg-preview.png" width="100" height="100" alt="Laptops">
	    </div>
	    <button class="prev-button" type="button" aria-label="Посмотреть предыдущий слайд">&lt;</button>
	    <button class="next-button" type="button" aria-label="Посмотреть следующий слайд">&gt;</button>
	  </div>
    <script src="script2.js"></script>



    <div class='cards'>

      <div class='container'>
  
         <div class='cards-holder'>
  
              <div class='card'>
  
                  <div class='card-image'>
                      <img class='card-img' src='img/card3_1.png'>
                  </div>
  
                  <div class='card-title'>
                    Best    <span>Technologies</span>
                  </div>
  
                  <div class='card-desc'>
                    Our store offers you world brands recognized by users
                  </div>
  
              </div>
  
              <div class='card'>
  
                  <div class='card-image'>
                      <img class='card-img' src='img/card3_1.png'>
                  </div>
  
                  <div class='card-title'>
                      Good  <span>Products</span>
                  </div>
  
                  <div class='card-desc'>
                    We have our suppliers in America, Europe, Asia
  
                  </div>
  
              </div>
  
              <div class='card'>
  
                  <div class='card-image'>
                      <img class='card-img' src='img/card3_1.png'>
                  </div>
  
                  <div class='card-title'>
                    Legitimate  <span>Prices</span>
                  </div>
  
                  <div class='card-desc'>
                    We have fair prices and low margins on our products
                  </div>
  
              </div>
  
          </div>
      </div>
    </div>














<div class="ccn">
  <div class="topic">
  Market <span>Products </span></div>
  <div class="topic_text">
    Our store provides only the best products
  </div>
<div class="row">
    <br><div class="content">
      <a href="log.html" class="mash" ><img src="img/png/i-removebg-preview.png" alt="Apple" style="width:100%"></a>
      <h4>Iphone 11 128GB  Black</h4><br>
      <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
    </div>
  
    <div class="content">
      <a href="log.html" class="mash" ><img src="img/png/i-14_fil-removebg-preview.png" alt="Apple" style="width:100%"></a>
      <h4>Iphone 14 Pro Max 256GB Violet</h4>
      <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
    </div><br>
  

    <div class="content">
      <a href="log.html" class="mash" ><img src="img/i-15pro.avif" alt="Apple" style="width:100%"></a>
      <h4>Iphone 15 Pro Max 256GB Gold</h4>
       <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
    </div><br>
      <div class="content">
        <a href="log.html" class="mash" ><img src="img/png/A-15_1.png" alt="Asus" style="width:100%"></a>
        <h4>ASUS TUF Gaming F15 FX506HE Black</h4><br>
        <a  class="buy" href="2page.html"> <img src="img/card.png" alt="">Buy</a> 
      </div>
      <div class="content">
        <a href="log.html" class="mash" ><img src="img/png/A-16-removebg-preview.png" alt="Asus" style="width:100%"></a>
        <h4>ASUS ROG Zephyrus M16 Black</h4><br>
        <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a> 
      </div>
   
      <div class="content">
        <a href="log.html" class="mash" ><img src="img/png/A-90-removebg-preview.png" alt="Asus" style="width:100%"></a>
        <h4>ASUS 15 F515EA-BQ2187W Gray</h4><br>
        <a  class="buy" href="log.html"> <img src="img/card.png" alt="">Buy</a>
        
      
    </div>
</div>
      <div class="box">
         <div class="his">
          Techno <span>Market</span>
         </div>
         <div class='his_text'>
              We are pleased to offer you a wide range of products from world leaders in innovative technologies. Here you can buy the latest models of iPhone, Oppo, Asus, Acer and other devices that impress with their quality and functionality.We are proud to provide only original products from leading companies that have passed rigorous testing and meet the highest quality standards. Our team is ready to help you choose and purchase the perfect device, as well as provide professional advice on all issues.

Do not postpone your dreams for later - make your life more comfortable and efficient with the products of world brands. Buy with confidence in our online store and enjoy advanced technologies today!
         </div>
         <div class='his_num'>
          <div class='num_i'>
              79 <span>Phones</span>
          </div>

          <div class='num_i'>
              32 <span>Laptops</span>
          </div>

          <div class='num_i'>
              102 <span>Accessories</span>
          </div>
      </div>
         </div>
        </div>
      </div>
      

  
   
  

<script src="js/anime.min.js"></script>
<script>
var animation = anime({
  targets: '.header-logo',
  rotate: {
    value: 360,
    duration: 2500, // Продолжительность анимации в миллисекундах (1 секунда)
    easing: 'easeInOutSine' // Эффект сглаживания для плавности анимации
  },
  loop: true
});
</script>

<script>
  var animation = anime({
  targets: '.card',
  translateX: 180,
  delay: function(el, i) { return i * 100; },
  direction: 'alternate',
  loop: true,
  easing: 'easeInOutSine'
});

document.querySelector('.restart-demo .restart').onclick = animation.restart;
</script>

<div class="container2">
<form action="contact.php" method="post">
  <div class="contact-box">
    <div class="left"></div>
    <div class="right">
      <h2>Contact Us</h2>
      <input type="text" class="field" placeholder="Your Name" id="uname" name="uname">
      <input type="text" class="field" placeholder="Your Phone" id="upho" name="upho">
      <input type="text" class="field" placeholder="Address" id="uadd" name="uadd">
      <textarea placeholder="Message" class="field" id="umes" name="umes"></textarea>
      <button class="btn" id="btn" name="btn"><a href="https://wa.me/87089713828?text=Hello! I want a consultation." id="btn" name="btn">Send</a></button>
    </div>
  </div>
</form>
</div>
  

<footer>
  <a href="mailto:TikoMiko@example.com" class="em">Email:TikoMiko@example.com</a>
  <div class="phone">
      <img src="img/call.png" alt="">
      <p>+87089717777</p>
  </div>
   <div class="sc">
<a href="https://www.facebook.com/" class="fa fa-facebook"></a>
<a href="https://twitter.com/?lang=en" class="fa fa-twitter"></a>
<a href="https://www.google.co.uk/" class="fa fa-google"></a>
<a href="https://kz.linkedin.com/" class="fa fa-linkedin"></a>
<a href="https://www.youtube.com/channel/UC2c3f-eBCcobf3WiYj1P_Qg" class="fa fa-youtube"></a>
<a href="https://www.instagram.com/mikh_ailkutuzov/" class="fa fa-instagram"></a>
</div>
</footer>










</div>

</body>
</html>