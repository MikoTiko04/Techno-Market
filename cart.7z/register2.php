<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    .container2{
	position: relative;
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
  max-height: 800px;
	padding: 30px 100px;
}

.container2:after{
	content: '';
	position: absolute;
	width: 100%;
	height: 170%;
	left: 0;
	top: 0;
    background: url(img/bg-1.jpg)no-repeat center;
	background-size: cover;
    height: 800px;
	z-index: -1;
}

.contact-box{
    max-width: 900px;
	display: grid;
	grid-template-columns: repeat(2, 1fr);
	justify-content: center;
	align-items: center;
	text-align: center;
	background-color:white;
	box-shadow: 0px 0px 19px 5px rgba(0,0,0,0.19);
    position: absolute;
    left: 25%;
    top:300%;
}

.left{
	background: url("img/bg6.jpeg") no-repeat center;
	background-size: cover;
	height: 100%;
}

.right{
	padding: 25px 40px;
    margin-right: 20px;
}

h2{
    position: relative;
	padding: 0 0 10px;
	margin-bottom: 10px;
  color: orange;
  font-family:"Sans Open", sans-serif;
    font-style: italic;
}

h2:after{
    content: '';
    position: absolute;
    left: 50%;
    bottom: 0;
    color: orange;
    transform: translateX(-50%);r
    height: 4px;
    width: 50px;
    border-radius: 2px;
    background-color: #00000000;
}

.field{
	width: 100%;
	border: 2px solid rgba(0, 0, 0, 0);
	outline: none;
	background-color: rgba(230, 230, 230, 0.6);
	padding: 0.5rem 1rem;
	font-size: 1.1rem;
	margin-bottom: 22px;
	transition: .3s;
}

.field:hover{
	background-color:floralwhite
}
.right input,textarea,button{
    color: orange;
    background-color: rgba(230, 230, 230, 0.6);
  }

textarea{
	min-height: 150px;
}

.btn{
	width: 100%;
	padding: 0.5rem 1rem;
	background-color: #00000000;
	color:orange;
	font-size: 1.1rem;
	border: none;
	outline: none;
	cursor: pointer;
	transition: .3s;
  font-family:"Sans Open", sans-serif;
  border: 2px solid rgba(30,85,250,0.47);
  background-color: #0072c6;
  max-width: 385px;
  position: absolute;
    left: 54.5%;
    top:90.5%;
}


.btn a{
    text-decoration: none;
    color: orange;
    font-family:"Sans Open", sans-serif;
  }

.field:focus{
    border: 2px solid rgba(30,85,250,0.47);
    background-color: #00000000;
}

@media screen and (max-width: 880px){
	.contact-box{
		grid-template-columns: 1fr;
	}
	.left{
		height: 200px;
	}
}
::-webkit-input-placeholder { /* WebKit browsers */
    color:#0072c6;
    font-family:"Sans Open", sans-serif;
    font-style: italic;
  }

  </style>
</head>
<body>
  

<div class="container2">
<form action="register.php" method="post">
  <div class="contact-box">
    <div class="left"></div>
    <div class="right">
      <h2>Register</h2>
      <input type="text" class="field" placeholder="Login" id="r_log" name="r_log">
      <input type="text" class="field" placeholder="Email" id="r_email" name="r_email">
      <input type="text" class="field" placeholder="Phone"id="p_log" name="p_log">
      <input type="text" class="field" placeholder="Password" id="pwd" name="pwd">
      <input type="text" class="field" placeholder="Repeat Password"id="rpwd" name="rpwd">
      <button class="btn" id="btn" name="btn"><a href="https://wa.me/87089713828?text=Hello! I want a consultation." id="btn" name="btn">Send</a></button>
    </div>
  </div>
</form>
</div>
</body>
</html>